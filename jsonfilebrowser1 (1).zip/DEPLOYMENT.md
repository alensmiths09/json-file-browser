# 🚀 Deploy to Vercel (Recommended)

## Step 1: Push to GitHub
\`\`\`bash
git add .
git commit -m "Ready for deployment"
git push origin main
\`\`\`

## Step 2: Deploy to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Sign up with GitHub
3. Click "New Project"
4. Import your `json-file-browser` repo
5. Click "Deploy"

## Step 3: Custom Domain (Optional)
1. In Vercel dashboard, go to your project
2. Click "Settings" → "Domains"
3. Add your custom domain
4. Update DNS records as shown

## Done! 🎉
Your app is live at: `https://your-project.vercel.app`

## Auto-Deploy Setup
Every time you push to GitHub, Vercel automatically:
- Builds your project
- Deploys updates
- Provides preview URLs for branches

## Environment Variables (if needed)
1. Go to Project Settings
2. Click "Environment Variables"
3. Add any API keys or config
