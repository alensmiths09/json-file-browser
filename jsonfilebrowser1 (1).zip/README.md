# JSON File Browser - Professional Data Extractor

A professional JSON data extractor and web file browser for course content analysis, built with Next.js and deployed for free.

## 🚀 Live Demo

**Try it now:** [Your Live URL Here]

## ✨ Features

- **Smart JSON Loading**: Load JSON files from URLs or upload directly
- **Interactive File Browser**: Navigate through folder structures with ease
- **Advanced Search**: Find files and folders quickly
- **File Type Icons**: Visual indicators for different file types (PDF, Video, Documents, etc.)
- **Export Options**: Download as JSON, CSV, or HTML
- **HTML Export**: Generate beautiful HTML reports for WordPress
- **CORS Proxy Support**: Automatic fallback for blocked URLs
- **Mobile Responsive**: Works perfectly on all devices
- **Smart Auto-Detection**: Automatically extracts course titles and branding

## 🛠️ Technology Stack

- **Framework**: Next.js 14 with App Router
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **TypeScript**: Full type safety
- **Deployment**: Vercel/Netlify/GitHub Pages

## 🏃‍♂️ Quick Start

### Try the Example
1. Visit the live application
2. Click "Load Ricky Mataka - Hybrid Income Protocol" 
3. Explore the file structure with enhanced icons
4. Try the HTML Export feature

### Upload Your Own JSON
1. Prepare a JSON file with this structure:
\`\`\`json
{
  "name": "Course Name",
  "type": "folder",
  "size": 1234567,
  "children": [
    {
      "name": "file.pdf",
      "type": "file", 
      "size": 123456
    }
  ]
}
\`\`\`
2. Upload via the interface or load from URL

## 🎯 Use Cases

- **Course Content Analysis**: Analyze online course structures
- **File System Visualization**: Browse JSON-based file trees
- **Content Auditing**: Generate reports for content verification
- **WordPress Integration**: Export HTML for easy embedding

## 🔧 Development

\`\`\`bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Export static files
npm run export
\`\`\`

## 📦 Deployment

### Option 1: Vercel (Recommended)
1. Push to GitHub
2. Connect to Vercel
3. Deploy automatically

### Option 2: Netlify
1. Push to GitHub
2. Connect to Netlify
3. Deploy with build command: \`npm run build\`

### Option 3: GitHub Pages
1. Enable GitHub Pages in repository settings
2. Use GitHub Actions for automatic deployment

## 🌟 Key Features Explained

### Smart Auto-Detection
- Automatically extracts course titles from filenames
- Sets appropriate branding (udcourse.com)
- Populates HTML export fields intelligently

### Enhanced File Icons
- PDF documents with red badges
- Video files (MP4, TS, etc.) with purple badges  
- Archive files with yellow badges
- Code files with gray badges
- And many more!

### CORS Handling
- Automatic proxy fallback for blocked URLs
- Multiple proxy services for reliability
- Helpful error messages and solutions

### Export Options
- **JSON**: Complete structure or current view
- **CSV**: Flat file list for spreadsheets
- **HTML**: Beautiful reports for WordPress

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - feel free to use this project for your own needs.

## 🔗 Links

- **GitHub Repository**: [Your GitHub URL]
- **Live Demo**: [Your Live URL]
- **udcourse.com**: [https://udcourse.com](https://udcourse.com)

---

Built with ❤️ for the udcourse.com community
