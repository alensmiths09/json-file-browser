// CORS Proxy utilities for handling cross-origin JSON requests

export interface CorsProxyConfig {
  name: string
  baseUrl: string
  formatUrl: (targetUrl: string) => string
  parseResponse: (response: any) => any
}

// Available CORS proxy services
export const CORS_PROXIES: CorsProxyConfig[] = [
  {
    name: "AllOrigins",
    baseUrl: "https://api.allorigins.win/get",
    formatUrl: (url: string) => `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
    parseResponse: (data: any) => {
      if (data.status && data.status.http_code !== 200) {
        throw new Error(`Target server returned ${data.status.http_code}`)
      }
      return JSON.parse(data.contents)
    },
  },
  {
    name: "CorsProxy.io",
    baseUrl: "https://corsproxy.io",
    formatUrl: (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    parseResponse: (data: any) => data,
  },
  {
    name: "CORS Anywhere (Demo)",
    baseUrl: "https://cors-anywhere.herokuapp.com",
    formatUrl: (url: string) => `https://cors-anywhere.herokuapp.com/${url}`,
    parseResponse: (data: any) => data,
  },
]

export async function fetchWithCorsProxy(url: string): Promise<{ data: any; method: string }> {
  // First, try direct fetch
  try {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }
    const data = await response.json()
    return { data, method: "direct" }
  } catch (directError) {
    console.log("Direct fetch failed, trying CORS proxies...", directError)
  }

  // If direct fails, try each proxy
  for (const proxy of CORS_PROXIES) {
    try {
      console.log(`Trying ${proxy.name}...`)

      const proxyUrl = proxy.formatUrl(url)
      const response = await fetch(proxyUrl)

      if (!response.ok) {
        throw new Error(`${proxy.name} returned ${response.status}: ${response.statusText}`)
      }

      const responseData = await response.json()
      const data = proxy.parseResponse(responseData)

      return { data, method: proxy.name.toLowerCase() }
    } catch (proxyError) {
      console.log(`${proxy.name} failed:`, proxyError)
      continue
    }
  }

  // If all proxies fail
  throw new Error("CORS_BLOCKED")
}

export function isCorsError(error: Error): boolean {
  return (
    error.message.includes("CORS") ||
    error.message.includes("Failed to fetch") ||
    error.message.includes("Network request failed") ||
    error.message === "CORS_BLOCKED"
  )
}

export function generateCorsErrorMessage(url: string): string {
  const hostname = new URL(url).hostname
  return `CORS Policy Error: The server at "${hostname}" does not allow cross-origin requests. Please try one of these solutions:

1. Download the JSON file and upload it instead
2. Use a different URL that supports CORS
3. Contact the website owner to enable CORS headers`
}

export function generateNetworkErrorMessage(url: string): string {
  return `Network Error: Unable to reach "${url}". This could be due to:

1. CORS policy blocking the request
2. Network connectivity issues
3. Invalid URL or server not responding

Try downloading the file and uploading it instead.`
}
