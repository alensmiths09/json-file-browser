import type { FileSystemItem } from "@/types"
import { formatFileSize, getFolderStats } from "@/utils/downloadUtils"
import type { HTMLExportData } from "./htmlExport"
import { getThemeCSS } from "./htmlExport"

const getBaseCSS = (): string => `
  * { box-sizing: border-box; }
  
  body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', sans-serif;
    line-height: 1.6;
    background: #f8f9fa;
    color: #212529;
    min-height: 100vh;
  }
  
  .container { max-width: 1200px; margin: 0 auto; padding: 0 1rem; }
  .main-content { padding: 2rem 0; }
  
  /* Simple Statistics Dashboard */
  .stats-section {
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
  }
  
  .stat-item {
    text-align: center;
    padding: 1rem;
    border: 1px solid #e9ecef;
    border-radius: 6px;
    background: #fff;
  }
  
  .stat-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--primary-color, #007bff);
    display: block;
    margin-bottom: 0.25rem;
  }
  
  .stat-label {
    font-size: 0.875rem;
    color: #6c757d;
    font-weight: 500;
  }
  
  /* Simple File Browser */
  .file-browser {
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    overflow: hidden;
  }
  
  .file-header {
    background: var(--primary-color, #007bff);
    color: white;
    padding: 1rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .file-header-title {
    font-size: 1.125rem;
    font-weight: 600;
  }
  
  .tree-controls {
    display: flex;
    gap: 0.5rem;
  }
  
  .tree-btn {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.375rem 0.75rem;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .tree-btn:hover {
    background: rgba(255,255,255,0.3);
  }
  
  /* Simple Tree Structure */
  .tree-list {
    padding: 0;
    margin: 0;
    list-style: none;
  }
  
  .tree-item {
    border-bottom: 1px solid #f1f3f4;
  }
  
  .tree-item:last-child {
    border-bottom: none;
  }
  
  .tree-content {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 1rem;
    padding: 0.75rem 1rem;
    align-items: center;
  }
  
  .tree-content:hover {
    background: #f8f9fa;
  }
  
  .tree-name {
    display: flex;
    align-items: center;
    font-weight: 500;
    color: #212529;
  }
  
  .tree-toggle {
    background: var(--primary-color, #007bff);
    border: none;
    cursor: pointer;
    padding: 0.25rem;
    margin-right: 0.5rem;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 1.5rem;
    height: 1.5rem;
    font-size: 0.75rem;
    color: white;
    font-weight: bold;
  }
  
  .tree-toggle:hover {
    background: var(--primary-color-dark, #0056b3);
  }
  
  .tree-toggle.hidden {
    visibility: hidden;
  }
  
  .tree-icon {
    margin-right: 0.5rem;
    font-size: 1.25rem;
  }
  
  .tree-type {
    color: #6c757d;
    font-size: 0.875rem;
    background: #f8f9fa;
    padding: 0.125rem 0.375rem;
    border-radius: 4px;
    font-weight: 500;
  }
  
  .tree-size {
    text-align: right;
    color: #6c757d;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .tree-children {
    margin-left: 2rem;
    border-left: 1px solid #e9ecef;
    padding-left: 1rem;
  }
  
  .tree-children.collapsed {
    display: none;
  }
  
  /* Enhanced Header with Logo */
  .header {
    background: var(--primary-color, #007bff);
    color: white;
    padding: 2rem 0;
  }
  
  .header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
  }
  
  .header-text {
    flex: 1;
  }
  
  .header-text h1 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0 0 0.5rem 0;
  }
  
  .header-text h2 {
    font-size: 1.125rem;
    font-weight: 400;
    margin: 0;
    opacity: 0.9;
  }
  
  .header-logo {
    flex-shrink: 0;
  }
  
  .header-logo a {
    display: inline-block;
    transition: opacity 0.2s ease;
  }
  
  .header-logo a:hover {
    opacity: 0.8;
  }
  
  .header-logo img {
    height: 60px;
    width: auto;
    max-width: 200px;
    object-fit: contain;
  }
  
  /* Simple Footer */
  .footer {
    background: #f8f9fa;
    border-top: 1px solid #e9ecef;
    padding: 1.5rem 0;
    text-align: center;
    color: #6c757d;
  }
  
  .watermark {
    position: fixed;
    bottom: 1rem;
    right: 1rem;
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 6px;
    padding: 0.5rem 0.75rem;
    font-size: 0.75rem;
    color: #6c757d;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    z-index: 1000;
  }
  
  /* Enhanced Responsive Design */
  @media (max-width: 768px) {
    .header-content {
      flex-direction: column;
      text-align: center;
    }
    
    .header-text h1 {
      font-size: 1.75rem;
    }
    
    .header-text h2 {
      font-size: 1rem;
    }
    
    .header-logo img {
      height: 50px;
    }
    
    .stats-section {
      grid-template-columns: 1fr;
    }
    
    .file-header {
      flex-direction: column;
      gap: 0.75rem;
    }
    
    .tree-content {
      grid-template-columns: 1fr;
      gap: 0.5rem;
    }
    
    .tree-size {
      text-align: left;
    }
    
    .tree-children {
      margin-left: 1.5rem;
    }
    
    .file-badge {
      font-size: 0.45rem;
      padding: 0.5px 2px;
    }
  }
  
  /* Enhanced File Type Icons with Color-Coded Badges */
  .file-icon {
    position: relative;
    display: inline-block;
    margin-right: 0.5rem;
    font-size: 1.25rem;
  }
  
  .file-badge {
    position: absolute;
    bottom: -3px;
    right: -12px;
    font-size: 0.5rem;
    font-weight: bold;
    padding: 1px 3px;
    border-radius: 2px;
    color: white;
    line-height: 1;
    min-width: 22px;
    text-align: center;
    font-family: Arial, sans-serif;
    box-shadow: 0 1px 2px rgba(0,0,0,0.2);
  }
  
  /* File Type Icon Colors - Unified System */
  .folder-icon { color: #007bff; }
  
  .pdf-icon { color: #dc2626; }
  .pdf-badge { background: #dc2626; }
  
  /* UNIFIED VIDEO ICON - Purple for ALL video formats */
  .video-icon { color: #7c3aed; }
  .video-badge { background: #7c3aed; }
  
  .doc-icon { color: #2563eb; }
  .doc-badge { background: #2563eb; }
  
  .spreadsheet-icon { color: #059669; }
  .spreadsheet-badge { background: #059669; }
  
  .presentation-icon { color: #ea580c; }
  .presentation-badge { background: #ea580c; }
  
  .archive-icon { color: #d97706; }
  .archive-badge { background: #d97706; }
  
  .image-icon { color: #db2777; }
  .image-badge { background: #db2777; }
  
  .audio-icon { color: #10b981; }
  .audio-badge { background: #10b981; }
  
  .code-icon { color: #475569; }
  .code-badge { background: #475569; }
  
  .text-icon { color: #6b7280; }
  .text-badge { background: #6b7280; }
  
  .default-icon { color: #6b7280; }
`

const getFileIcon = (item: FileSystemItem): string => {
  if (item.type === "folder") {
    return '<span class="file-icon folder-icon" title="Folder">📁</span>'
  }

  const ext = item.name.split(".").pop()?.toLowerCase() || ""

  // UNIFIED VIDEO FILES - Single icon for ALL video formats
  if (["mp4", "ts", "avi", "mov", "mkv", "wmv", "flv", "m4v", "webm"].includes(ext)) {
    return '<span class="file-icon video-icon" title="Video File">🎬<span class="file-badge video-badge">VIDEO</span></span>'
  }

  // PDF Files - High priority for course content
  if (ext === "pdf") {
    return '<span class="file-icon pdf-icon" title="PDF Document">📄<span class="file-badge pdf-badge">PDF</span></span>'
  }

  // Document Files
  if (["doc", "docx", "txt"].includes(ext)) {
    return '<span class="file-icon doc-icon" title="Document">📝<span class="file-badge doc-badge">DOC</span></span>'
  }

  // Spreadsheet Files
  if (["xls", "xlsx", "csv"].includes(ext)) {
    return '<span class="file-icon spreadsheet-icon" title="Spreadsheet">📊<span class="file-badge spreadsheet-badge">XLS</span></span>'
  }

  // Presentation Files
  if (["ppt", "pptx"].includes(ext)) {
    return '<span class="file-icon presentation-icon" title="Presentation">📋<span class="file-badge presentation-badge">PPT</span></span>'
  }

  // Archive Files
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) {
    return '<span class="file-icon archive-icon" title="Archive">🗂️<span class="file-badge archive-badge">ZIP</span></span>'
  }

  // Image Files
  if (["jpg", "jpeg", "png", "gif", "bmp", "svg", "webp"].includes(ext)) {
    return '<span class="file-icon image-icon" title="Image">🖼️<span class="file-badge image-badge">IMG</span></span>'
  }

  // Audio Files
  if (["mp3", "wav", "flac", "aac", "ogg", "m4a"].includes(ext)) {
    return '<span class="file-icon audio-icon" title="Audio">🎵<span class="file-badge audio-badge">AUDIO</span></span>'
  }

  // Code Files (excluding TypeScript which is now grouped with videos)
  if (["js", "jsx", "py", "java", "cpp", "c", "php", "rb", "go", "html", "css"].includes(ext)) {
    return '<span class="file-icon code-icon" title="Code File">⚙️<span class="file-badge code-badge">CODE</span></span>'
  }

  // Markdown Files
  if (["md", "rtf"].includes(ext)) {
    return '<span class="file-icon text-icon" title="Text File">📝<span class="file-badge text-badge">TXT</span></span>'
  }

  // Default file icon
  return '<span class="file-icon default-icon" title="File">📋</span>'
}

const generateFileListHTML = (items: FileSystemItem[], level = 0): string => {
  return items
    .map((item) => {
      const icon = getFileIcon(item)
      const type = item.type === "folder" ? "Folder" : (item.name.split(".").pop()?.toUpperCase() || "File") + " File"
      const size = item.type === "folder" ? "—" : formatFileSize(item.size)
      const itemId = `item-${Math.random().toString(36).substr(2, 9)}`
      const childrenId = `children-${Math.random().toString(36).substr(2, 9)}`

      const isFolder = item.type === "folder"
      const hasChildren = isFolder && item.children && item.children.length > 0

      let html = `<li class="tree-item">
      <div class="tree-content">
        <div class="tree-name">
          ${
            hasChildren
              ? `<button class="tree-toggle" onclick="toggleFolder('${childrenId}', this)" aria-label="Toggle folder">
              <span class="toggle-icon">+</span>
            </button>`
              : `<span class="tree-toggle hidden"></span>`
          }
          <span class="tree-icon">${icon}</span>
          ${item.name}
        </div>
        <div class="tree-type">${type}</div>
        <div class="tree-size">${size}</div>
      </div>`

      if (hasChildren) {
        html += `
      <ul class="tree-children collapsed" id="${childrenId}">
        ${generateFileListHTML(item.children!, level + 1)}
      </ul>`
      }

      html += `</li>`
      return html
    })
    .join("")
}

const getTreeJavaScript = (): string => `
<script>
// Tree navigation functionality
function toggleFolder(childrenId, button) {
  const children = document.getElementById(childrenId);
  const icon = button.querySelector('.toggle-icon');
  
  if (children.classList.contains('collapsed')) {
    children.classList.remove('collapsed');
    icon.textContent = '-';
    button.setAttribute('aria-expanded', 'true');
  } else {
    children.classList.add('collapsed');
    icon.textContent = '+';
    button.setAttribute('aria-expanded', 'false');
  }
}

// Expand all folders
function expandAll() {
  const allChildren = document.querySelectorAll('.tree-children');
  const allToggleIcons = document.querySelectorAll('.toggle-icon');
  
  allChildren.forEach(children => {
    children.classList.remove('collapsed');
  });
  
  allToggleIcons.forEach(icon => {
    icon.textContent = '-';
    const button = icon.closest('.tree-toggle');
    if (button) {
      button.setAttribute('aria-expanded', 'true');
    }
  });
}

// Collapse all folders
function collapseAll() {
  const allChildren = document.querySelectorAll('.tree-children');
  const allToggleIcons = document.querySelectorAll('.toggle-icon');
  
  allChildren.forEach(children => {
    children.classList.add('collapsed');
  });
  
  allToggleIcons.forEach(icon => {
    icon.textContent = '+';
    const button = icon.closest('.tree-toggle');
    if (button) {
      button.setAttribute('aria-expanded', 'false');
    }
  });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  // Set initial aria-expanded attributes
  const toggleButtons = document.querySelectorAll('.tree-toggle');
  toggleButtons.forEach(button => {
    if (!button.classList.contains('hidden')) {
      button.setAttribute('aria-expanded', 'false');
    }
  });
  
  // Add keyboard navigation
  toggleButtons.forEach(button => {
    button.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        button.click();
      }
    });
  });
});
</script>
`

export const generateHTML = (exportData: HTMLExportData): string => {
  const { data, options, timestamp, sourceUrl } = exportData
  const stats = getFolderStats([data])
  const themeCSS = getThemeCSS(options.theme, options.primaryColor || "", options.secondaryColor || "")

  const statsHTML = options.includeStats
    ? `
    <div class="stats-section">
      <div class="stat-item">
        <span class="stat-value">${stats.totalFiles}</span>
        <span class="stat-label">Total Files</span>
      </div>
      <div class="stat-item">
        <span class="stat-value">${stats.totalFolders}</span>
        <span class="stat-label">Folders</span>
      </div>
      <div class="stat-item">
        <span class="stat-value">${formatFileSize(stats.totalSize)}</span>
        <span class="stat-label">Content Size</span>
      </div>
    </div>`
    : ""

  const footerHTML = options.includeFooter
    ? `
    <footer class="footer">
      <div class="container">
        <p>${options.customFooter || `Generated by ${options.brandName} | Course Content Verification`}</p>
      </div>
    </footer>`
    : ""

  const watermarkHTML = options.watermark ? `<div class="watermark">${options.watermark}</div>` : ""

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${options.brandName} - ${options.courseTitle}</title>
  <style>${themeCSS}${getBaseCSS()}</style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <div class="header-text">
          <h1>${options.brandName}</h1>
          <h2>${options.courseTitle} - Course Content</h2>
        </div>
        <div class="header-logo">
          <a href="https://udcourse.com" target="_blank" rel="noopener noreferrer" title="Visit udcourse.com">
            <img src="https://udcourse.com/wp-content/uploads/2022/12/cropped-ud-course-378-%C3%97-133-px-52-Converted.png" 
                 alt="udcourse.com" />
          </a>
        </div>
      </div>
    </div>
  </header>
  <main class="main-content">
    <div class="container">
      ${statsHTML}
      <div class="file-browser">
        <div class="file-header">
          <div class="file-header-title">
            Course Content
          </div>
          <div class="tree-controls">
            <button class="tree-btn" onclick="expandAll()" title="Show all content">
              Show All
            </button>
            <button class="tree-btn" onclick="collapseAll()" title="Hide folders">
              Hide All
            </button>
          </div>
        </div>
        <ul class="tree-list">${generateFileListHTML([data])}</ul>
      </div>
    </div>
  </main>
  ${footerHTML}
  ${watermarkHTML}
  ${getTreeJavaScript()}
</body>
</html>`
}

export const downloadHTML = (filename: string, htmlContent: string): void => {
  try {
    console.log("Starting HTML download...", { filename, contentLength: htmlContent.length })

    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" })
    const url = URL.createObjectURL(blob)

    const link = document.createElement("a")
    link.href = url
    link.download = filename.endsWith(".html") ? filename : `${filename}.html`
    link.style.display = "none"

    // Add to DOM, click, and remove
    document.body.appendChild(link)
    console.log("Download link created and added to DOM")

    // Force click with better timing
    setTimeout(() => {
      link.click()
      console.log("Download link clicked")

      // Clean up
      setTimeout(() => {
        document.body.removeChild(link)
        URL.revokeObjectURL(url)
        console.log("Download cleanup completed")
      }, 500)
    }, 100)
  } catch (error) {
    console.error("HTML download failed:", error)
    throw new Error(`Failed to download HTML file: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

export const previewHTML = (htmlContent: string): void => {
  const newWindow = window.open("", "_blank")
  if (newWindow) {
    newWindow.document.write(htmlContent)
    newWindow.document.close()
  }
}
