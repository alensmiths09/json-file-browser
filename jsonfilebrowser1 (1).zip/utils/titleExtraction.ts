/**
 * Utility functions for automatic title extraction and smart defaults
 */

/**
 * Extract course title from URL filename
 * @param url - The JSON file URL
 * @returns Cleaned course title or empty string if invalid
 */
export function extractTitleFromUrl(url: string): string {
  try {
    // Extract filename from URL path
    const urlPath = new URL(url).pathname
    const filename = urlPath.split("/").pop() || ""

    // Remove .json extension
    const nameWithoutExtension = filename.replace(/\.json$/i, "")

    if (!nameWithoutExtension) {
      return ""
    }

    // Split by hyphens and process each word
    const words = nameWithoutExtension.split("-").filter((word) => word.length > 0)

    // Apply proper capitalization and join with spaces
    const title = words
      .map((word) => {
        // Handle special cases for common abbreviations
        const lowerWord = word.toLowerCase()
        if (["api", "seo", "css", "html", "js", "ai", "ui", "ux"].includes(lowerWord)) {
          return word.toUpperCase()
        }

        // Standard title case
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      })
      .join(" ")

    return title
  } catch (error) {
    // If URL parsing fails, try simple filename extraction
    try {
      const filename = url.split("/").pop() || ""
      const nameWithoutExtension = filename.replace(/\.json$/i, "")

      if (!nameWithoutExtension) {
        return ""
      }

      const words = nameWithoutExtension.split("-").filter((word) => word.length > 0)
      return words.map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(" ")
    } catch {
      return ""
    }
  }
}

/**
 * Get default brand name
 * @returns Default brand name for udcourse
 */
export function getDefaultBrandName(): string {
  return "udcourse.com"
}

/**
 * Check if a URL appears to be a JSON file URL
 * @param url - URL to check
 * @returns true if URL ends with .json
 */
export function isJsonUrl(url: string): boolean {
  try {
    const urlPath = new URL(url).pathname
    return urlPath.toLowerCase().endsWith(".json")
  } catch {
    return url.toLowerCase().includes(".json")
  }
}

/**
 * Generate smart defaults for HTML export based on data source
 * @param dataSource - The source of the data (URL or file info)
 * @returns Object with smart defaults for brand name and course title
 */
export function generateSmartDefaults(dataSource: string): { brandName: string; courseTitle: string } {
  const brandName = getDefaultBrandName()
  let courseTitle = ""

  // Check if data source is a URL
  if (dataSource.startsWith("URL:")) {
    const url = dataSource.replace("URL:", "").split("(")[0].trim() // Remove proxy info
    if (isJsonUrl(url)) {
      courseTitle = extractTitleFromUrl(url)
    }
  }
  // Check if data source is a file
  else if (dataSource.startsWith("File:")) {
    const filename = dataSource.replace("File:", "").trim()
    if (filename.toLowerCase().endsWith(".json")) {
      const nameWithoutExtension = filename.replace(/\.json$/i, "")
      const words = nameWithoutExtension.split(/[-_\s]+/).filter((word) => word.length > 0)
      courseTitle = words.map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(" ")
    }
  }

  return { brandName, courseTitle }
}

/**
 * Format course title for display in the UI
 * @param title - Raw extracted title
 * @returns Formatted title with proper spacing and capitalization
 */
export function formatCourseTitle(title: string): string {
  if (!title.trim()) {
    return ""
  }

  // Clean up any extra spaces and ensure proper formatting
  return title
    .split(/\s+/)
    .filter((word) => word.length > 0)
    .map((word) => {
      // Keep existing capitalization for acronyms
      if (word === word.toUpperCase() && word.length <= 4) {
        return word
      }
      // Standard title case for other words
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    })
    .join(" ")
}
