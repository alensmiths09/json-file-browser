import type { FileSystemItem, SearchResult, TreeNode } from "@/types"

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

export function searchFileSystem(items: FileSystemItem[], query: string, basePath: string[] = []): SearchResult[] {
  const results: SearchResult[] = []
  const lowerQuery = query.toLowerCase()

  for (const item of items) {
    const currentPath = [...basePath, item.name]

    // Check if current item matches
    if (item.name.toLowerCase().includes(lowerQuery)) {
      results.push({
        item,
        path: currentPath,
      })
    }

    // Search in children if it's a folder
    if (item.type === "folder" && item.children) {
      results.push(...searchFileSystem(item.children, query, currentPath))
    }
  }

  return results
}

export function buildTreeNodes(
  items: FileSystemItem[],
  expandedPaths: Set<string>,
  basePath: string[] = [],
  level = 0,
): TreeNode[] {
  return items.map((item) => {
    const currentPath = [...basePath, item.name]
    const pathKey = currentPath.join("/")
    const isExpanded = expandedPaths.has(pathKey)

    const node: TreeNode = {
      item,
      path: currentPath,
      level,
      isExpanded,
    }

    if (item.type === "folder" && item.children && isExpanded) {
      node.children = buildTreeNodes(item.children, expandedPaths, currentPath, level + 1)
    }

    return node
  })
}

export function getItemsAtPath(rootItems: FileSystemItem[], path: string[]): FileSystemItem[] {
  if (path.length === 0) return rootItems

  let current = rootItems
  for (const pathPart of path) {
    const folder = current.find((item) => item.name === pathPart && item.type === "folder")
    if (!folder || !folder.children) return []
    current = folder.children
  }

  return current
}

export function getTotalSize(items: FileSystemItem[]): number {
  return items.reduce((total, item) => {
    if (item.type === "folder" && item.children) {
      return total + getTotalSize(item.children)
    }
    return total + item.size
  }, 0)
}
