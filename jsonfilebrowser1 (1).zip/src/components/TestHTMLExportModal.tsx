import React from 'react';
import { X } from 'lucide-react';

interface TestHTMLExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestHTMLExportModal: React.FC<TestHTMLExportModalProps> = ({ isOpen, onClose }) => {
  console.log('TestHTMLExportModal rendered, isOpen:', isOpen);
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Test HTML Export Modal</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>
        <p className="text-gray-600 mb-4">This is a test modal to verify the basic modal functionality is working.</p>
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
          >
            Close
          </button>
          <button
            onClick={() => alert('Test export button clicked!')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Test Export
          </button>
        </div>
      </div>
    </div>
  );
};
