import React, { useState } from 'react';
import { Upload, Globe, Loader2, AlertCircle, Download } from 'lucide-react';
import { FileSystemItem } from '@/types';
import { cn } from '@/lib/utils';
import { fetchWithCorsProxy, isCorsError, generateCorsErrorMessage, generateNetworkErrorMessage } from '@/utils/corsProxy';
import { DownloadHelper } from './DownloadHelper';

interface InputSectionProps {
  onDataLoaded: (data: FileSystemItem, source: string) => void;
  onError: (error: string) => void;
  isLoading: boolean;
  error: string | null;
}

export const InputSection: React.FC<InputSectionProps> = ({
  onDataLoaded,
  onError,
  isLoading,
  error
}) => {
  const [urlInput, setUrlInput] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [showDownloadHelper, setShowDownloadHelper] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState('');
  
  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    
    const url = urlInput.trim();
    
    try {
      const { data, method } = await fetchWithCorsProxy(url);
      
      // Validate JSON structure
      validateJsonStructure(data);
      
      // Success message with method used
      const sourceInfo = method === 'direct' 
        ? `URL: ${url}` 
        : `URL: ${url} (via ${method} proxy)`;
      
      onDataLoaded(data, sourceInfo);
      
    } catch (err) {
      let errorMessage;
      
      if (err instanceof Error) {
        if (err.message === 'CORS_BLOCKED') {
          errorMessage = generateCorsErrorMessage(url);
          // Show download helper for CORS blocked URLs
          setDownloadUrl(url);
          setShowDownloadHelper(true);
        } else if (isCorsError(err)) {
          errorMessage = generateNetworkErrorMessage(url);
        } else {
          errorMessage = `Failed to load JSON from URL: ${err.message}`;
        }
      } else {
        errorMessage = 'Failed to load JSON from URL: Unknown error';
      }
      
      onError(errorMessage);
    }
  };
  
  const handleShowDownloadHelper = () => {
    if (urlInput.trim()) {
      setDownloadUrl(urlInput.trim());
      setShowDownloadHelper(true);
    }
  };
  
  const handleFileChange = (file: File) => {
    try {
      if (!file.type.includes('json') && !file.name.endsWith('.json')) {
        throw new Error('Please select a JSON file');
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          validateJsonStructure(data);
          onDataLoaded(data, `File: ${file.name}`);
        } catch (err) {
          const errorMessage = `Invalid JSON file: ${err instanceof Error ? err.message : 'Parse error'}`;
          onError(errorMessage);
        }
      };
      
      reader.onerror = () => {
        onError('Failed to read file');
      };
      
      reader.readAsText(file);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'File processing error';
      onError(errorMessage);
    }
  };
  
  const validateJsonStructure = (data: any) => {
    if (!data || typeof data !== 'object') {
      throw new Error('JSON must be an object');
    }
    
    if (!data.name || !data.type) {
      throw new Error('JSON must have "name" and "type" properties');
    }
    
    if (data.type !== 'folder' && data.type !== 'file') {
      throw new Error('"type" must be either "folder" or "file"');
    }
    
    if (typeof data.size !== 'number') {
      throw new Error('"size" must be a number');
    }
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    try {
      const files = Array.from(e.dataTransfer.files);
      if (files.length > 0) {
        handleFileChange(files[0]);
      } else {
        onError('No files were dropped');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Drag and drop error';
      onError(errorMessage);
    }
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  };
  
  return (
    <div className="bg-white border-b border-gray-200 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">
            JSON Data Extractor & Web File Browser
          </h1>
          <a 
            href="https://udcourse.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center hover:opacity-80 transition-opacity duration-200"
            title="Visit udcourse.com"
          >
            <img 
              src="https://udcourse.com/wp-content/uploads/2022/12/cropped-ud-course-378-%C3%97-133-px-52-Converted.png" 
              alt="udcourse.com" 
              className="h-10 w-auto hover:scale-105 transition-transform duration-200"
              onError={(e) => {
                // Fallback if image fails to load
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const fallback = document.createElement('div');
                fallback.className = 'px-3 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 transition-colors';
                fallback.textContent = 'udcourse.com';
                target.parentNode?.appendChild(fallback);
              }}
            />
          </a>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* URL Input */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Load from URL
            </label>
            <form onSubmit={handleUrlSubmit} className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
              <div className="flex-1 relative">
                <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com/data.json"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  disabled={isLoading}
                />
              </div>
              <button
                type="submit"
                disabled={isLoading || !urlInput.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 sm:flex-shrink-0"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <span>Load</span>
                )}
              </button>
            </form>
          </div>
          
          {/* File Upload */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Upload JSON File
            </label>
            <div
              className={cn(
                'border-2 border-dashed rounded-md p-4 text-center transition-colors',
                dragActive
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-400',
                isLoading && 'opacity-50 cursor-not-allowed'
              )}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
            >
              <input
                type="file"
                accept=".json,application/json"
                onChange={(e) => {
                  try {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleFileChange(file);
                    }
                  } catch (err) {
                    const errorMessage = err instanceof Error ? err.message : 'File selection error';
                    onError(errorMessage);
                  }
                }}
                className="hidden"
                id="file-upload"
                disabled={isLoading}
              />
              <label
                htmlFor="file-upload"
                className="cursor-pointer flex flex-col items-center space-y-2"
              >
                <Upload className="w-8 h-8 text-gray-400" />
                <div className="text-sm text-gray-600">
                  <span className="font-medium text-blue-600 hover:text-blue-500">
                    Click to upload
                  </span>
                  {' '}or drag and drop
                </div>
                <div className="text-xs text-gray-500">JSON files only</div>
              </label>
            </div>
          </div>
        </div>
        
        {/* Error Display */}
        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-sm text-red-800 font-medium mb-1">
                  {error.includes('CORS Policy Error') ? 'CORS Policy Error' :
                   error.includes('Network Error') ? 'Network Error' : 'Error'}
                </div>
                <div className="text-sm text-red-700 whitespace-pre-wrap">{error}</div>
                
                {/* Additional Help for CORS Errors */}
                {(error.includes('CORS') || error.includes('Failed to fetch')) && (
                  <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-blue-800">
                        <strong>💡 Quick Solution:</strong> Download the file manually and upload it instead.
                      </div>
                      <button
                        onClick={handleShowDownloadHelper}
                        className="flex items-center space-x-1 px-2 py-1 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded text-xs font-medium"
                      >
                        <Download className="w-3 h-3" />
                        <span>Help Download</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Quick Load Example & CORS Info */}
        <div className="mt-4 space-y-3">
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
            <div className="text-sm text-blue-800">
              <div className="flex flex-col sm:flex-row sm:items-center mb-2">
                <span className="font-semibold mb-1 sm:mb-0 sm:mr-2">✨ Try Smart Auto-Detection:</span>
                <button
                  onClick={async () => {
                    const exampleUrl = 'https://imarketing.courses/wp-content/uploads/2025/07/Ricky-Mataka-Hybrid-Income-Protocol.json';
                    setUrlInput(exampleUrl);
                    
                    try {
                      const { data, method } = await fetchWithCorsProxy(exampleUrl);
                      validateJsonStructure(data);
                      const sourceInfo = method === 'direct' 
                        ? `URL: ${exampleUrl}` 
                        : `URL: ${exampleUrl} (via ${method} proxy)`;
                      onDataLoaded(data, sourceInfo);
                    } catch (err) {
                      let errorMessage;
                      if (err instanceof Error) {
                        if (err.message === 'CORS_BLOCKED') {
                          errorMessage = generateCorsErrorMessage(exampleUrl);
                          setDownloadUrl(exampleUrl);
                          setShowDownloadHelper(true);
                        } else if (isCorsError(err)) {
                          errorMessage = generateNetworkErrorMessage(exampleUrl);
                        } else {
                          errorMessage = `Failed to load JSON from URL: ${err.message}`;
                        }
                      } else {
                        errorMessage = 'Failed to load JSON from URL: Unknown error';
                      }
                      onError(errorMessage);
                    }
                  }}
                  className="text-blue-600 hover:text-blue-800 underline text-left sm:text-center transition-colors font-medium"
                  disabled={isLoading}
                  data-testid="load-example-button"
                >
                  {isLoading ? 'Loading...' : 'Load "Ricky Mataka - Hybrid Income Protocol"'}
                </button>
              </div>
              <div className="text-xs text-blue-700 bg-blue-100 p-2 rounded">
                <strong>🚀 New Features:</strong> When you load this example, watch how the system:
                <br />• 🏷️ Displays <strong>file type icons</strong> (PDF, Video, TS files, etc.)
                <br />• 🎬 Automatically extracts "Ricky Mataka - Hybrid Income Protocol" as course title
                <br />• 🏢 Sets "udcourse.com" branding with <strong>clickable logo</strong>
                <br />• ✨ Then try HTML Export to see smart auto-population + enhanced icons!
              </div>
            </div>
          </div>
          
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-md">
            <div className="text-xs text-amber-800">
              <div className="font-semibold mb-1">🛡️ CORS Protection Notice:</div>
              <div>Some websites block cross-origin requests for security. If URL loading fails, 
              the app will automatically try CORS proxy services. If that fails, download the JSON file 
              and use the upload option instead.</div>
            </div>
          </div>
        </div>
        
        {/* Download Helper Modal */}
        {showDownloadHelper && (
          <DownloadHelper
            url={downloadUrl}
            onClose={() => setShowDownloadHelper(false)}
          />
        )}
      </div>
    </div>
  );
};
