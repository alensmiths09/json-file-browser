import React from 'react';

// Testing helper component to expose dropdown menu for automation
export const TestingDropdownTrigger: React.FC<{
  onShowMenu: () => void;
  children: React.ReactNode;
}> = ({ onShowMenu, children }) => {
  React.useEffect(() => {
    // Expose trigger function for testing
    (window as any).triggerDownloadMenu = onShowMenu;
    
    return () => {
      delete (window as any).triggerDownloadMenu;
    };
  }, [onShowMenu]);
  
  return <>{children}</>;
};

// Testing helper to expose file actions
export const TestingFileActionsTrigger: React.FC<{
  fileName: string;
  onShowActions: () => void;
  children: React.ReactNode;
}> = ({ fileName, onShowActions, children }) => {
  React.useEffect(() => {
    // Expose trigger function for testing
    (window as any)[`triggerFileActions_${fileName}`] = onShowActions;
    
    return () => {
      delete (window as any)[`triggerFileActions_${fileName}`];
    };
  }, [fileName, onShowActions]);
  
  return <>{children}</>;
};

// Testing status component
export const TestingStatus: React.FC = () => {
  const [isVisible, setIsVisible] = React.useState(false);
  
  React.useEffect(() => {
    // Show/hide based on URL parameter for testing
    const urlParams = new URLSearchParams(window.location.search);
    setIsVisible(urlParams.get('testing') === 'true');
  }, []);
  
  if (!isVisible) return null;
  
  return (
    <div 
      className="fixed bottom-4 left-4 bg-yellow-100 border border-yellow-300 rounded-lg p-3 z-50"
      data-testid="testing-status"
    >
      <div className="text-xs font-mono text-yellow-800">
        Testing Mode Active
      </div>
      <div className="text-xs text-yellow-700 mt-1">
        Use window.triggerDownloadMenu() to show dropdown
      </div>
    </div>
  );
};
