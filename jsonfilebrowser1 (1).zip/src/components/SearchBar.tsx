import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { SearchResult } from '@/types';
import { formatFileSize } from '@/utils/fileSystem';
import { cn } from '@/lib/utils';

interface SearchBarProps {
  searchResults: SearchResult[];
  onSearch: (query: string) => void;
  onSelectResult: (result: SearchResult) => void;
  isSearching: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchResults,
  onSearch,
  onSelectResult,
  isSearching
}) => {
  const [query, setQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  
  useEffect(() => {
    const delayedSearch = setTimeout(() => {
      onSearch(query);
      setShowResults(query.length > 0);
    }, 300);
    
    return () => clearTimeout(delayedSearch);
  }, [query, onSearch]);
  
  const handleClear = () => {
    setQuery('');
    setShowResults(false);
    onSearch('');
  };
  
  const handleResultClick = (result: SearchResult) => {
    setShowResults(false);
    onSelectResult(result);
  };
  
  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search files and folders..."
          className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          onFocus={() => setShowResults(query.length > 0)}
          onBlur={() => setTimeout(() => setShowResults(false), 200)}
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      
      {/* Search Results Dropdown */}
      {showResults && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-96 overflow-auto">
          {isSearching ? (
            <div className="p-4 text-center text-gray-500">
              <div className="animate-pulse">Searching...</div>
            </div>
          ) : searchResults.length > 0 ? (
            <div className="py-1">
              {searchResults.slice(0, 50).map((result, index) => (
                <button
                  key={`${result.path.join('/')}-${index}`}
                  onClick={() => handleResultClick(result)}
                  className="w-full px-3 sm:px-4 py-2 text-left hover:bg-blue-50 flex flex-col sm:flex-row sm:items-center sm:justify-between group"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1 sm:mb-0">
                      <span className="font-medium text-gray-900 truncate text-sm">
                        {result.item.name}
                      </span>
                      <span className={cn(
                        'text-xs px-2 py-0.5 rounded-full flex-shrink-0',
                        result.item.type === 'folder'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-gray-100 text-gray-800'
                      )}>
                        {result.item.type}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 truncate">
                      Path: {result.path.slice(0, -1).join(' > ')}
                    </div>
                  </div>
                  {result.item.type === 'file' && (
                    <div className="text-xs text-gray-400 mt-1 sm:mt-0 sm:ml-2 text-left sm:text-right">
                      {formatFileSize(result.item.size)}
                    </div>
                  )}
                </button>
              ))}
              {searchResults.length > 50 && (
                <div className="px-3 sm:px-4 py-2 text-xs text-gray-500 border-t border-gray-100">
                  Showing first 50 of {searchResults.length} results
                </div>
              )}
            </div>
          ) : query.length > 0 ? (
            <div className="p-4 text-center text-gray-500">
              <div className="text-sm">No results found for "{query}"</div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};
