export interface FileSystemItem {
  name: string;
  type: 'file' | 'folder';
  size: number;
  children?: FileSystemItem[];
}

export interface SearchResult {
  item: FileSystemItem;
  path: string[];
}

export interface TreeNode {
  item: FileSystemItem;
  path: string[];
  level: number;
  isExpanded: boolean;
  parent?: TreeNode;
  children?: TreeNode[];
}
