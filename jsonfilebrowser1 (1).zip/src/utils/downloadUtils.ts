import { FileSystemItem } from '@/types';

// Download utilities for JSON data and file structures

export interface DownloadOptions {
  filename: string;
  data: any;
  type?: 'json' | 'text' | 'csv';
}

export function downloadAsJson(options: DownloadOptions): void {
  const { filename, data } = options;
  
  try {
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.endsWith('.json') ? filename : `${filename}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up the URL object
    setTimeout(() => URL.revokeObjectURL(url), 100);
  } catch (error) {
    console.error('Download failed:', error);
    throw new Error('Failed to download file');
  }
}

export function downloadAsText(filename: string, content: string): void {
  try {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.endsWith('.txt') ? filename : `${filename}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(() => URL.revokeObjectURL(url), 100);
  } catch (error) {
    console.error('Download failed:', error);
    throw new Error('Failed to download file');
  }
}

export function downloadAsCSV(filename: string, data: any[]): void {
  try {
    if (!data.length) {
      throw new Error('No data to export');
    }
    
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          // Escape quotes and wrap in quotes if contains comma
          if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        }).join(',')
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(() => URL.revokeObjectURL(url), 100);
  } catch (error) {
    console.error('CSV download failed:', error);
    throw new Error('Failed to download CSV file');
  }
}

export function generateFileList(items: FileSystemItem[], currentPath: string[] = []): any[] {
  const fileList: any[] = [];
  
  for (const item of items) {
    const fullPath = [...currentPath, item.name].join('/');
    
    fileList.push({
      name: item.name,
      type: item.type,
      size: item.size,
      path: fullPath,
      sizeFormatted: formatFileSize(item.size)
    });
    
    if (item.type === 'folder' && item.children) {
      fileList.push(...generateFileList(item.children, [...currentPath, item.name]));
    }
  }
  
  return fileList;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function generateFileName(baseName: string, extension: string = 'json'): string {
  const timestamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
  const cleanBaseName = baseName.replace(/[^a-zA-Z0-9-_]/g, '_');
  return `${cleanBaseName}_${timestamp}.${extension}`;
}

export function getFolderStats(items: FileSystemItem[]): {
  totalFiles: number;
  totalFolders: number;
  totalSize: number;
} {
  let totalFiles = 0;
  let totalFolders = 0;
  let totalSize = 0;
  
  for (const item of items) {
    if (item.type === 'file') {
      totalFiles++;
      totalSize += item.size;
    } else if (item.type === 'folder') {
      totalFolders++;
      if (item.children) {
        const childStats = getFolderStats(item.children);
        totalFiles += childStats.totalFiles;
        totalFolders += childStats.totalFolders;
        totalSize += childStats.totalSize;
      }
    }
  }
  
  return { totalFiles, totalFolders, totalSize };
}
