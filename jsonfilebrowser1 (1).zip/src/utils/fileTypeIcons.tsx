import React from 'react';
import { 
  File, 
  Folder, 
  FolderOpen, 
  FileText, 
  Play, 
  FileType, 
  Archive, 
  Image, 
  Music,
  Code,
  Globe,
  FileSpreadsheet,
  Presentation,
  Database
} from 'lucide-react';
import { FileSystemItem } from '@/types';

/**
 * File type icon mapping with colors and specific icons for course content
 */
export interface FileTypeInfo {
  icon: React.ReactNode;
  color: string;
  category: string;
  description: string;
}

const getFileExtension = (filename: string): string => {
  return filename.split('.').pop()?.toLowerCase() || '';
};

export const getFileTypeInfo = (item: FileSystemItem): FileTypeInfo => {
  if (item.type === 'folder') {
    return {
      icon: <Folder className="w-4 h-4" />,
      color: 'text-blue-600',
      category: 'folder',
      description: 'Folder'
    };
  }
  
  const extension = getFileExtension(item.name);
  
  // PDF Files - High priority for course content
  if (extension === 'pdf') {
    return {
      icon: <FileText className="w-4 h-4" />,
      color: 'text-red-600',
      category: 'document',
      description: 'PDF Document'
    };
  }
  
  // Video Files - Common in course content
  if (['mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'm4v', 'webm'].includes(extension)) {
    return {
      icon: <Play className="w-4 h-4" />,
      color: 'text-purple-600',
      category: 'video',
      description: 'Video File'
    };
  }
  
  // TS Files - Video transport streams in course context
  if (extension === 'ts') {
    return {
      icon: <Play className="w-4 h-4" />,
      color: 'text-indigo-600',
      category: 'video',
      description: 'Video Stream'
    };
  }
  
  // Document Files
  if (['doc', 'docx'].includes(extension)) {
    return {
      icon: <FileText className="w-4 h-4" />,
      color: 'text-blue-600',
      category: 'document',
      description: 'Word Document'
    };
  }
  
  // Spreadsheet Files
  if (['xls', 'xlsx', 'csv'].includes(extension)) {
    return {
      icon: <FileSpreadsheet className="w-4 h-4" />,
      color: 'text-green-600',
      category: 'spreadsheet',
      description: 'Spreadsheet'
    };
  }
  
  // Presentation Files
  if (['ppt', 'pptx'].includes(extension)) {
    return {
      icon: <Presentation className="w-4 h-4" />,
      color: 'text-orange-600',
      category: 'presentation',
      description: 'Presentation'
    };
  }
  
  // Archive Files
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension)) {
    return {
      icon: <Archive className="w-4 h-4" />,
      color: 'text-yellow-600',
      category: 'archive',
      description: 'Archive'
    };
  }
  
  // Image Files
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'].includes(extension)) {
    return {
      icon: <Image className="w-4 h-4" />,
      color: 'text-pink-600',
      category: 'image',
      description: 'Image File'
    };
  }
  
  // Audio Files
  if (['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a'].includes(extension)) {
    return {
      icon: <Music className="w-4 h-4" />,
      color: 'text-green-500',
      category: 'audio',
      description: 'Audio File'
    };
  }
  
  // Code Files
  if (['js', 'jsx', 'tsx', 'py', 'java', 'cpp', 'c', 'php', 'rb', 'go'].includes(extension)) {
    return {
      icon: <Code className="w-4 h-4" />,
      color: 'text-slate-600',
      category: 'code',
      description: 'Code File'
    };
  }
  
  // TypeScript Files (code context)
  if (extension === 'ts' && !['mp4', 'avi', 'mov'].some(vid => item.name.includes(vid))) {
    return {
      icon: <Code className="w-4 h-4" />,
      color: 'text-blue-700',
      category: 'code',
      description: 'TypeScript File'
    };
  }
  
  // Web Files
  if (['html', 'htm', 'css', 'xml'].includes(extension)) {
    return {
      icon: <Globe className="w-4 h-4" />,
      color: 'text-blue-500',
      category: 'web',
      description: 'Web File'
    };
  }
  
  // Database Files
  if (['sql', 'db', 'sqlite', 'mdb'].includes(extension)) {
    return {
      icon: <Database className="w-4 h-4" />,
      color: 'text-slate-700',
      category: 'database',
      description: 'Database File'
    };
  }
  
  // Text Files
  if (['txt', 'md', 'rtf'].includes(extension)) {
    return {
      icon: <FileType className="w-4 h-4" />,
      color: 'text-gray-600',
      category: 'text',
      description: 'Text File'
    };
  }
  
  // Default file icon
  return {
    icon: <File className="w-4 h-4" />,
    color: 'text-gray-600',
    category: 'file',
    description: extension ? `${extension.toUpperCase()} File` : 'File'
  };
};

/**
 * Get folder icon based on expanded state
 */
export const getFolderIcon = (isExpanded: boolean = false): React.ReactNode => {
  return isExpanded ? (
    <FolderOpen className="w-4 h-4 text-blue-600" />
  ) : (
    <Folder className="w-4 h-4 text-blue-600" />
  );
};

/**
 * Get file type category for styling and organization
 */
export const getFileCategory = (item: FileSystemItem): string => {
  return getFileTypeInfo(item).category;
};

/**
 * Get human-readable file type description
 */
export const getFileTypeDescription = (item: FileSystemItem): string => {
  return getFileTypeInfo(item).description;
};
