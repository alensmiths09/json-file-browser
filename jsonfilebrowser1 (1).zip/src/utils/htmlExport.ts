export interface HTMLExportOptions {
  brandName: string;
  courseTitle: string;
  theme: 'professional' | 'modern' | 'corporate';
  includeStats: boolean;
  watermark?: string;
  customLogo?: string;
  primaryColor?: string;
  secondaryColor?: string;
  includeFooter: boolean;
  customFooter?: string;
}

export interface HTMLExportData {
  data: any;
  options: HTMLExportOptions;
  timestamp: string;
  sourceUrl?: string;
}

export const getThemeCSS = (theme: string, primaryColor: string, secondaryColor: string): string => {
  const themes = {
    professional: `
      :root {
        --primary-color: ${primaryColor || '#1e40af'};
        --secondary-color: ${secondaryColor || '#64748b'};
        --background: #ffffff;
        --surface: #f8fafc;
        --border: #e2e8f0;
        --text-primary: #1e293b;
        --text-secondary: #64748b;
        --hover: #f1f5f9;
      }
      body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
        background: var(--background);
        color: var(--text-primary);
      }
      .header {
        background: linear-gradient(135deg, var(--primary-color), #3b82f6);
        color: white;
        padding: 2rem 0;
        text-align: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      }
    `,
    modern: `
      :root {
        --primary-color: ${primaryColor || '#7c3aed'};
        --secondary-color: ${secondaryColor || '#a855f7'};
        --background: #fafafa;
        --surface: #ffffff;
        --border: #e4e4e7;
        --text-primary: #18181b;
        --text-secondary: #71717a;
        --hover: #f4f4f5;
      }
      body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        line-height: 1.5;
        margin: 0;
        padding: 0;
        background: var(--background);
        color: var(--text-primary);
      }
      .header {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        padding: 3rem 0;
        text-align: center;
      }
    `,
    corporate: `
      :root {
        --primary-color: ${primaryColor || '#059669'};
        --secondary-color: ${secondaryColor || '#047857'};
        --background: #ffffff;
        --surface: #f9fafb;
        --border: #d1d5db;
        --text-primary: #111827;
        --text-secondary: #6b7280;
        --hover: #f3f4f6;
      }
      body {
        font-family: 'Georgia', 'Times New Roman', serif;
        line-height: 1.7;
        margin: 0;
        padding: 0;
        background: var(--background);
        color: var(--text-primary);
      }
      .header {
        background: var(--primary-color);
        color: white;
        padding: 2.5rem 0;
        text-align: center;
        border-bottom: 4px solid var(--secondary-color);
      }
    `
  };
  
  return themes[theme as keyof typeof themes] || themes.professional;
};
