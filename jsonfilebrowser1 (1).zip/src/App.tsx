import React, { useState, useCallback, useMemo } from 'react';
import { InputSection } from '@/components/InputSection';
import { SearchBar } from '@/components/SearchBar';
import { TreeView } from '@/components/TreeView';
import { FileListView } from '@/components/FileListView';
import { ActionToolbar } from '@/components/ActionToolbar';
import { FileSystemItem, SearchResult } from '@/types';
import {
  searchFileSystem,
  buildTreeNodes,
  getItemsAtPath,
  formatFileSize,
  getTotalSize
} from '@/utils/fileSystem';
import { Folder, HardDrive, Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';

function App() {
  const [data, setData] = useState<FileSystemItem | null>(null);
  const [dataSource, setDataSource] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  const [selectedPath, setSelectedPath] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isMobileTreeVisible, setIsMobileTreeVisible] = useState(false);
  
  const handleDataLoaded = useCallback(async (newData: FileSystemItem, source: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Simulate loading delay for better UX
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setData(newData);
      setDataSource(source);
      setSelectedPath([]);
      setExpandedPaths(new Set([newData.name])); // Expand root by default
      setSearchQuery('');
      setSearchResults([]);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load data';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const handleError = useCallback((errorMessage: string) => {
    setError(errorMessage);
    setIsLoading(false);
  }, []);
  
  const handleClearData = useCallback(() => {
    setData(null);
    setDataSource('');
    setError(null);
    setSelectedPath([]);
    setExpandedPaths(new Set());
    setSearchQuery('');
    setSearchResults([]);
    setIsMobileTreeVisible(false);
  }, []);
  
  const handleSearch = useCallback(async (query: string) => {
    setSearchQuery(query);
    
    if (!data || query.trim() === '') {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }
    
    setIsSearching(true);
    
    // Simulate search delay
    setTimeout(() => {
      const results = searchFileSystem([data], query.trim());
      setSearchResults(results);
      setIsSearching(false);
    }, 150);
  }, [data]);
  
  const handleSelectSearchResult = useCallback((result: SearchResult) => {
    // Navigate to the parent folder of the search result
    const parentPath = result.path.slice(0, -1);
    setSelectedPath(parentPath);
    
    // Expand all folders in the path
    const newExpandedPaths = new Set(expandedPaths);
    for (let i = 1; i <= parentPath.length; i++) {
      const pathToExpand = parentPath.slice(0, i);
      newExpandedPaths.add(pathToExpand.join('/'));
    }
    setExpandedPaths(newExpandedPaths);
    
    setSearchQuery('');
    setSearchResults([]);
  }, [expandedPaths]);
  
  const handleToggleExpand = useCallback((path: string[]) => {
    const pathKey = path.join('/');
    const newExpandedPaths = new Set(expandedPaths);
    
    if (newExpandedPaths.has(pathKey)) {
      newExpandedPaths.delete(pathKey);
    } else {
      newExpandedPaths.add(pathKey);
    }
    
    setExpandedPaths(newExpandedPaths);
  }, [expandedPaths]);
  
  const handleSelectFolder = useCallback((path: string[]) => {
    setSelectedPath(path);
  }, []);
  
  const handleFolderDoubleClick = useCallback((folderName: string) => {
    const newPath = [...selectedPath, folderName];
    setSelectedPath(newPath);
    
    // Auto-expand the folder
    const pathKey = newPath.join('/');
    if (!expandedPaths.has(pathKey)) {
      setExpandedPaths(prev => new Set([...prev, pathKey]));
    }
  }, [selectedPath, expandedPaths]);
  
  // Memoized computations
  const treeNodes = useMemo(() => {
    if (!data) return [];
    return buildTreeNodes([data], expandedPaths);
  }, [data, expandedPaths]);
  
  const currentItems = useMemo(() => {
    if (!data) return [];
    return getItemsAtPath([data], selectedPath);
  }, [data, selectedPath]);
  
  const statsInfo = useMemo(() => {
    if (!data) return null;
    
    const totalSize = getTotalSize([data]);
    const countItems = (items: FileSystemItem[]): { files: number; folders: number } => {
      let files = 0;
      let folders = 0;
      
      for (const item of items) {
        if (item.type === 'file') {
          files++;
        } else {
          folders++;
          if (item.children) {
            const childCounts = countItems(item.children);
            files += childCounts.files;
            folders += childCounts.folders;
          }
        }
      }
      
      return { files, folders };
    };
    
    const counts = countItems([data]);
    return {
      totalSize: formatFileSize(totalSize),
      totalFiles: counts.files,
      totalFolders: counts.folders
    };
  }, [data]);
  
  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <InputSection
        onDataLoaded={handleDataLoaded}
        onError={handleError}
        isLoading={isLoading}
        error={error}
      />
      
      {data && (
        <>
          {/* Action Toolbar */}
          <ActionToolbar
            data={data}
            currentItems={currentItems}
            currentPath={selectedPath}
            searchResults={searchResults}
            searchQuery={searchQuery}
            dataSource={dataSource}
            onClear={handleClearData}
          />
          
          {/* Search Bar */}
          <div className="bg-white border-b border-gray-200 p-4">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center justify-between space-x-4">
                {/* Mobile Menu Button */}
                <button
                  onClick={() => setIsMobileTreeVisible(!isMobileTreeVisible)}
                  className="lg:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md"
                  aria-label="Toggle folder tree"
                >
                  {isMobileTreeVisible ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
                
                <div className="flex-1 max-w-md">
                  <SearchBar
                    searchResults={searchResults}
                    onSearch={handleSearch}
                    onSelectResult={handleSelectSearchResult}
                    isSearching={isSearching}
                  />
                </div>
                
                {/* Stats - Hidden on small screens */}
                {statsInfo && (
                  <div className="hidden md:flex items-center space-x-4 lg:space-x-6 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <HardDrive className="w-4 h-4" />
                      <span className="hidden lg:inline">{statsInfo.totalSize}</span>
                      <span className="lg:hidden">{statsInfo.totalSize.split(' ')[0]}{statsInfo.totalSize.split(' ')[1].charAt(0)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Folder className="w-4 h-4" />
                      <span className="hidden lg:inline">{statsInfo.totalFolders} folders</span>
                      <span className="lg:hidden">{statsInfo.totalFolders}f</span>
                    </div>
                    <div>
                      <span className="hidden lg:inline">{statsInfo.totalFiles} files</span>
                      <span className="lg:hidden">{statsInfo.totalFiles}f</span>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Source Info */}
              <div className="mt-2 text-xs text-gray-500 truncate">
                Source: {dataSource}
              </div>
              
              {/* Mobile Stats */}
              {statsInfo && (
                <div className="md:hidden mt-2 flex items-center space-x-4 text-xs text-gray-600">
                  <span>{statsInfo.totalSize}</span>
                  <span>{statsInfo.totalFolders} folders</span>
                  <span>{statsInfo.totalFiles} files</span>
                </div>
              )}
            </div>
          </div>
          
          {/* Main Content */}
          <div className="flex-1 flex min-h-0 relative">
            <div className="max-w-6xl mx-auto flex w-full">
              {/* Tree View - Left Panel */}
              <div className={cn(
                "border-r border-gray-200 transition-all duration-300 ease-in-out",
                "lg:w-80 lg:flex-shrink-0 lg:relative", // Desktop: fixed width, always visible
                "absolute lg:static top-0 left-0 h-full bg-white z-10", // Mobile: overlay
                isMobileTreeVisible ? "w-72" : "w-0 lg:w-80", // Mobile: toggle width
                isMobileTreeVisible ? "" : "overflow-hidden lg:overflow-visible" // Mobile: hide overflow when closed
              )}>
                <TreeView
                  nodes={treeNodes}
                  onToggleExpand={handleToggleExpand}
                  onSelectFolder={handleSelectFolder}
                  selectedPath={selectedPath}
                />
              </div>
              
              {/* Mobile Overlay */}
              {isMobileTreeVisible && (
                <div 
                  className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-5"
                  onClick={() => setIsMobileTreeVisible(false)}
                />
              )}
              
              {/* File List - Right Panel */}
              <div className="flex-1 min-w-0">
                <FileListView
                  items={currentItems}
                  currentPath={selectedPath}
                  selectedPath={selectedPath}
                  onFolderDoubleClick={handleFolderDoubleClick}
                />
              </div>
            </div>
          </div>
        </>
      )}
      
      {/* Loading State */}
      {isLoading && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading JSON data...</p>
          </div>
        </div>
      )}
      
      {/* Empty State */}
      {!data && !isLoading && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Folder className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">
              Welcome to JSON File Browser
            </h2>
            <p className="text-gray-500 mb-4">
              Load a JSON file to explore its hierarchical structure
            </p>
            <p className="text-sm text-gray-400">
              Support for files with folder/file tree structures
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
