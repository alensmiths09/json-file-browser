"use client"

import type React from "react"
import { Folder } from "lucide-react"
import type { FileSystemItem } from "@/types"
import { formatFileSize } from "@/utils/fileSystem"
import { FileActions } from "@/components/FileActions"
import { getFileTypeInfo, getFileTypeDescription } from "@/utils/fileTypeIcons"
import { cn } from "@/lib/utils"

interface FileListViewProps {
  items: FileSystemItem[]
  currentPath: string[]
  selectedPath: string[]
  onFolderDoubleClick: (folderName: string) => void
}

const getFileIcon = (item: FileSystemItem) => {
  const typeInfo = getFileTypeInfo(item)
  return <div className={`${typeInfo.color} flex items-center justify-center`}>{typeInfo.icon}</div>
}

export const FileListView: React.FC<FileListViewProps> = ({
  items,
  currentPath,
  selectedPath,
  onFolderDoubleClick,
}) => {
  const sortedItems = [...items].sort((a, b) => {
    // Folders first, then files
    if (a.type !== b.type) {
      return a.type === "folder" ? -1 : 1
    }
    // Then alphabetically
    return a.name.localeCompare(b.name)
  })

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="p-3 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-700">Contents</h3>
          <div className="text-xs text-gray-500">
            {items.length} item{items.length !== 1 ? "s" : ""}
          </div>
        </div>
        {currentPath.length > 0 && (
          <div className="text-xs text-gray-600 mt-1 truncate" title={currentPath.join(" > ")}>
            Path: {currentPath.join(" > ")}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-auto">
        <div className="p-2">
          {/* Header */}
          <div className="grid grid-cols-12 gap-2 py-2 px-3 text-xs font-semibold text-gray-600 border-b border-gray-200 bg-gray-50">
            <div className="col-span-5 sm:col-span-4">Name</div>
            <div className="col-span-3 hidden sm:block">Type</div>
            <div className="col-span-3 sm:col-span-3 text-right">Size</div>
            <div className="col-span-1 sm:col-span-2 text-center">Actions</div>
          </div>

          {/* Items */}
          <div className="divide-y divide-gray-100">
            {sortedItems.map((item, index) => (
              <div
                key={`${item.name}-${index}`}
                className={cn(
                  "grid grid-cols-12 gap-2 py-2 px-3 hover:bg-blue-50 cursor-pointer group",
                  "transition-colors duration-150",
                )}
                onDoubleClick={() => {
                  if (item.type === "folder") {
                    onFolderDoubleClick(item.name)
                  }
                }}
              >
                <div className="col-span-5 sm:col-span-4 flex items-center min-w-0">
                  <div className="mr-2 flex-shrink-0">{getFileIcon(item)}</div>
                  <div className="min-w-0 flex-1">
                    <span className="text-sm text-gray-800 truncate block" title={item.name}>
                      {item.name}
                    </span>
                    {/* Mobile: Show type below name */}
                    <span className="text-xs text-gray-500 block sm:hidden truncate">
                      {getFileTypeDescription(item)}
                    </span>
                  </div>
                </div>

                {/* Desktop: Separate type column */}
                <div className="col-span-3 hidden sm:flex items-center">
                  <span className="text-sm text-gray-600 truncate">{getFileTypeDescription(item)}</span>
                </div>

                <div className="col-span-3 sm:col-span-3 flex items-center justify-end">
                  <span className="text-sm text-gray-600">
                    {item.type === "folder" ? "—" : formatFileSize(item.size)}
                  </span>
                </div>

                {/* Actions column */}
                <div className="col-span-1 sm:col-span-2 flex items-center justify-center">
                  <FileActions item={item} currentPath={selectedPath} />
                </div>
              </div>
            ))}
          </div>

          {items.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Folder className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">This folder is empty</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
