"use client"

import type React from "react"
import { useState } from "react"
import { Download, Info, Copy, Check } from "lucide-react"
import type { FileSystemItem } from "@/types"
import { formatFileSize, downloadAsJson, generateFileName } from "@/utils/downloadUtils"
import { cn } from "@/lib/utils"

interface FileActionsProps {
  item: FileSystemItem
  currentPath: string[]
}

interface FileInfoModalProps {
  item: FileSystemItem
  path: string[]
  onClose: () => void
}

const FileInfoModal: React.FC<FileInfoModalProps> = ({ item, path, onClose }) => {
  const [copied, setCopied] = useState<string | null>(null)

  const fullPath = [...path, item.name].join("/")

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(type)
      setTimeout(() => setCopied(null), 2000)
    } catch (err) {
      console.error("Failed to copy:", err)
    }
  }

  const downloadFileInfo = () => {
    const fileInfo = {
      name: item.name,
      type: item.type,
      size: item.size,
      sizeFormatted: formatFileSize(item.size),
      path: fullPath,
      parentPath: path.join("/"),
      timestamp: new Date().toISOString(),
      ...(item.children && { childCount: item.children.length }),
    }

    const filename = generateFileName(`file-info-${item.name}`)
    downloadAsJson({ filename, data: fileInfo })
  }

  const getFileExtension = (name: string) => {
    const parts = name.split(".")
    return parts.length > 1 ? parts.pop()?.toUpperCase() : "Unknown"
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      data-testid="file-info-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="file-info-title"
    >
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 id="file-info-title" className="text-lg font-semibold text-gray-900">
            File Information
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-xl"
            data-testid="file-info-close"
            aria-label="Close file information"
          >
            ×
          </button>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-1 gap-3">
              <div>
                <label className="text-sm font-medium text-gray-600">Name:</label>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-gray-900 font-mono text-sm break-all">{item.name}</span>
                  <button
                    onClick={() => copyToClipboard(item.name, "name")}
                    className="p-1 text-gray-400 hover:text-gray-600"
                    title="Copy name"
                  >
                    {copied === "name" ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-600">Type:</label>
                <div className="mt-1">
                  <span
                    className={cn(
                      "inline-block px-2 py-1 text-xs rounded-full",
                      item.type === "folder" ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800",
                    )}
                  >
                    {item.type === "file" ? `${getFileExtension(item.name)} File` : "Folder"}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-600">Size:</label>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-gray-900">{formatFileSize(item.size)}</span>
                  <span className="text-gray-500 text-sm">({item.size.toLocaleString()} bytes)</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-600">Path:</label>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-gray-900 font-mono text-sm break-all">{fullPath}</span>
                  <button
                    onClick={() => copyToClipboard(fullPath, "path")}
                    className="p-1 text-gray-400 hover:text-gray-600"
                    title="Copy path"
                  >
                    {copied === "path" ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {item.type === "folder" && item.children && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Contents:</label>
                  <div className="mt-1 text-gray-900">
                    {item.children.length} item{item.children.length !== 1 ? "s" : ""}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="text-sm text-blue-800">
              <div className="font-medium mb-2">📝 Note about downloads:</div>
              <div className="text-xs">
                This JSON file browser shows the structure and metadata of files, but doesn't contain the actual file
                contents. You can download the file information as JSON, or use this metadata to locate the actual
                files.
              </div>
            </div>
          </div>

          <div className="flex space-x-3">
            <button
              onClick={downloadFileInfo}
              className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              data-testid="download-file-info"
              aria-label="Download file information as JSON"
            >
              <Download className="w-4 h-4" />
              <span>Download Info</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 border border-gray-300 rounded-md hover:bg-gray-50"
              data-testid="file-info-modal-close"
              aria-label="Close file information modal"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export const FileActions: React.FC<FileActionsProps> = ({ item, currentPath }) => {
  const [showInfo, setShowInfo] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)

  const handleQuickDownload = async () => {
    setIsDownloading(true)
    try {
      const fileData = {
        name: item.name,
        type: item.type,
        size: item.size,
        sizeFormatted: formatFileSize(item.size),
        path: [...currentPath, item.name].join("/"),
        metadata: {
          downloadedAt: new Date().toISOString(),
          source: "JSON File Browser",
        },
      }

      const filename = generateFileName(`metadata-${item.name}`)
      downloadAsJson({ filename, data: fileData })
    } catch (error) {
      console.error("Download failed:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <>
      <div
        className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity"
        data-testid={`file-actions-${item.name}`}
      >
        <button
          onClick={() => setShowInfo(true)}
          className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
          title="View file information"
          data-testid={`file-info-button-${item.name}`}
          aria-label={`View information for ${item.name}`}
        >
          <Info className="w-4 h-4" />
        </button>

        <button
          onClick={handleQuickDownload}
          disabled={isDownloading}
          className="p-1 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded transition-colors disabled:opacity-50"
          title="Download file metadata"
          data-testid={`file-download-button-${item.name}`}
          aria-label={`Download metadata for ${item.name}`}
        >
          <Download className={cn("w-4 h-4", isDownloading && "animate-pulse")} />
        </button>
      </div>

      {showInfo && <FileInfoModal item={item} path={currentPath} onClose={() => setShowInfo(false)} />}
    </>
  )
}
