"use client"

import type React from "react"
import { ChevronRight, ChevronDown } from "lucide-react"
import type { TreeNode } from "@/types"
import { getFolderIcon, getFileTypeInfo } from "@/utils/fileTypeIcons"
import { cn } from "@/lib/utils"

interface TreeViewProps {
  nodes: TreeNode[]
  onToggleExpand: (path: string[]) => void
  onSelectFolder: (path: string[]) => void
  selectedPath: string[]
}

const TreeViewItem: React.FC<{
  node: TreeNode
  onToggleExpand: (path: string[]) => void
  onSelectFolder: (path: string[]) => void
  selectedPath: string[]
}> = ({ node, onToggleExpand, onSelectFolder, selectedPath }) => {
  const isSelected = JSON.stringify(selectedPath) === JSON.stringify(node.path)
  const hasChildren = node.item.type === "folder" && node.item.children && node.item.children.length > 0

  const handleClick = () => {
    if (node.item.type === "folder") {
      onSelectFolder(node.path)
      if (hasChildren) {
        onToggleExpand(node.path)
      }
    }
  }

  return (
    <div>
      <div
        className={cn(
          "flex items-center py-1 px-2 cursor-pointer hover:bg-blue-50 select-none",
          isSelected && "bg-blue-100 border-l-2 border-blue-500",
        )}
        style={{ paddingLeft: `${node.level * 16 + 8}px` }}
        onClick={handleClick}
      >
        <div className="flex items-center flex-1 min-w-0">
          {hasChildren ? (
            <div className="flex items-center mr-1">
              {node.isExpanded ? (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-600" />
              )}
            </div>
          ) : (
            <div className="w-5" />
          )}

          <div className="flex items-center mr-2">
            {node.item.type === "folder" ? (
              getFolderIcon(node.isExpanded)
            ) : (
              <div className={getFileTypeInfo(node.item).color}>{getFileTypeInfo(node.item).icon}</div>
            )}
          </div>

          <span className="text-sm text-gray-800 truncate" title={node.item.name}>
            {node.item.name}
          </span>
        </div>
      </div>

      {node.children && (
        <div>
          {node.children.map((child, index) => (
            <TreeViewItem
              key={`${child.path.join("/")}-${index}`}
              node={child}
              onToggleExpand={onToggleExpand}
              onSelectFolder={onSelectFolder}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export const TreeView: React.FC<TreeViewProps> = ({ nodes, onToggleExpand, onSelectFolder, selectedPath }) => {
  return (
    <div className="h-full overflow-auto bg-white border-r border-gray-200">
      <div className="p-3 border-b border-gray-200 bg-gray-50">
        <h3 className="text-sm font-semibold text-gray-700">Folder Tree</h3>
      </div>
      <div className="p-2">
        {nodes.map((node, index) => (
          <TreeViewItem
            key={`${node.path.join("/")}-${index}`}
            node={node}
            onToggleExpand={onToggleExpand}
            onSelectFolder={onSelectFolder}
            selectedPath={selectedPath}
          />
        ))}
      </div>
    </div>
  )
}
