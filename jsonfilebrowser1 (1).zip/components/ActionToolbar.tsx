"use client"

import React, { useState } from "react"
import { Download, RotateCcw, FileText, Table, Archive, AlertTriangle, CheckCircle, Globe } from "lucide-react"
import type { FileSystemItem, SearchResult } from "@/types"
import {
  downloadAsJson,
  downloadAsCSV,
  generateFileList,
  generateFileName,
  getFolderStats,
} from "@/utils/downloadUtils"
import { HTMLExportModal } from "@/components/HTMLExportModal"
import { cn } from "@/lib/utils"

interface ActionToolbarProps {
  data: FileSystemItem | null
  currentItems: FileSystemItem[]
  currentPath: string[]
  searchResults: SearchResult[]
  searchQuery: string
  dataSource: string
  onClear: () => void
}

interface ConfirmDialogProps {
  isOpen: boolean
  title: string
  message: string
  onConfirm: () => void
  onCancel: () => void
}

const ConfirmDialog: React.FC<ConfirmDialogProps> = ({ isOpen, title, message, onConfirm, onCancel }) => {
  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      data-testid="confirm-clear-dialog"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dialog-title"
    >
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <div className="flex items-center space-x-3 mb-4">
          <AlertTriangle className="w-6 h-6 text-amber-500" />
          <h3 id="dialog-title" className="text-lg font-semibold text-gray-900">
            {title}
          </h3>
        </div>

        <p className="text-gray-600 mb-6">{message}</p>

        <div className="flex space-x-3 justify-end">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-600 hover:text-gray-800 border border-gray-300 rounded-md hover:bg-gray-50"
            data-testid="cancel-clear-button"
            aria-label="Cancel clear operation"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
            data-testid="confirm-clear-button"
            aria-label="Confirm clear all data"
          >
            Clear Data
          </button>
        </div>
      </div>
    </div>
  )
}

interface NotificationProps {
  message: string
  type: "success" | "error"
  onClose: () => void
}

const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
  React.useEffect(() => {
    const timer = setTimeout(onClose, 3000)
    return () => clearTimeout(timer)
  }, [onClose])

  return (
    <div className="fixed top-4 right-4 z-50">
      <div
        className={cn(
          "flex items-center space-x-2 px-4 py-3 rounded-md shadow-lg",
          type === "success"
            ? "bg-green-100 text-green-800 border border-green-200"
            : "bg-red-100 text-red-800 border border-red-200",
        )}
        data-testid={`notification-${type}`}
        role="alert"
        aria-live="polite"
      >
        {type === "success" ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
        <span className="text-sm font-medium">{message}</span>
        <button
          onClick={onClose}
          className="ml-2 text-gray-400 hover:text-gray-600"
          data-testid="notification-close"
          aria-label="Close notification"
        >
          ×
        </button>
      </div>
    </div>
  )
}

export const ActionToolbar: React.FC<ActionToolbarProps> = ({
  data,
  currentItems,
  currentPath,
  searchResults,
  searchQuery,
  dataSource,
  onClear,
}) => {
  const [showConfirmClear, setShowConfirmClear] = useState(false)
  const [showDownloadMenu, setShowDownloadMenu] = useState(false)
  const [showHTMLExportModal, setShowHTMLExportModal] = useState(false)
  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null)

  const showNotification = (message: string, type: "success" | "error") => {
    setNotification({ message, type })
  }

  const handleDownloadComplete = () => {
    onClear()
    setShowConfirmClear(false)
    showNotification("Data cleared successfully", "success")
  }

  const handleDownloadError = (error: string) => {
    showNotification(`Download failed: ${error}`, "error")
  }

  const downloadCompleteStructure = () => {
    if (!data) return

    try {
      const filename = generateFileName(data.name || "json-structure")
      downloadAsJson({ filename, data })
      showNotification("Complete structure downloaded successfully", "success")
      setShowDownloadMenu(false)
    } catch (error) {
      handleDownloadError(error instanceof Error ? error.message : "Unknown error")
      setShowDownloadMenu(false)
    }
  }

  const downloadCurrentView = () => {
    if (!currentItems.length) return

    try {
      const viewData = {
        path: currentPath,
        items: currentItems,
        stats: getFolderStats(currentItems),
        timestamp: new Date().toISOString(),
      }

      const pathName = currentPath.length > 0 ? currentPath.join("_") : "root"
      const filename = generateFileName(`current-view-${pathName}`)
      downloadAsJson({ filename, data: viewData })
      showNotification("Current view downloaded successfully", "success")
      setShowDownloadMenu(false)
    } catch (error) {
      handleDownloadError(error instanceof Error ? error.message : "Unknown error")
      setShowDownloadMenu(false)
    }
  }

  const downloadSearchResults = () => {
    if (!searchResults.length) return

    try {
      const searchData = {
        query: searchQuery,
        results: searchResults.map((result) => ({
          name: result.item.name,
          type: result.item.type,
          size: result.item.size,
          path: result.path.join("/"),
          item: result.item,
        })),
        timestamp: new Date().toISOString(),
        totalResults: searchResults.length,
      }

      const filename = generateFileName(`search-results-${searchQuery}`)
      downloadAsJson({ filename, data: searchData })
      showNotification("Search results downloaded successfully", "success")
      setShowDownloadMenu(false)
    } catch (error) {
      handleDownloadError(error instanceof Error ? error.message : "Unknown error")
      setShowDownloadMenu(false)
    }
  }

  const downloadFileList = () => {
    if (!data) return

    try {
      const fileList = generateFileList([data])
      const filename = generateFileName(data.name || "file-list", "csv")
      downloadAsCSV(filename, fileList)
      showNotification("File list downloaded successfully", "success")
      setShowDownloadMenu(false)
    } catch (error) {
      handleDownloadError(error instanceof Error ? error.message : "Unknown error")
      setShowDownloadMenu(false)
    }
  }

  if (!data) {
    return null
  }

  return (
    <>
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between">
            {/* Left side - Info */}
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900">Data Actions</h2>
              <div className="text-sm text-gray-500">
                {currentPath.length > 0 ? <span>Viewing: {currentPath.join(" > ")}</span> : <span>Root folder</span>}
              </div>
            </div>

            {/* Right side - Actions */}
            <div className="flex items-center space-x-2">
              {/* Download Dropdown */}
              <div className="relative" data-testid="download-dropdown">
                <button
                  className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  data-testid="download-button"
                  aria-label="Download options"
                  aria-expanded={showDownloadMenu}
                  aria-haspopup="true"
                  onClick={() => setShowDownloadMenu(!showDownloadMenu)}
                  onMouseEnter={() => setShowDownloadMenu(true)}
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Download</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {/* Dropdown Menu */}
                <div
                  className={`absolute right-0 mt-1 w-64 bg-white border border-gray-200 rounded-md shadow-lg transition-all duration-200 z-20 ${
                    showDownloadMenu ? "opacity-100 visible" : "opacity-0 invisible"
                  }`}
                  data-testid="download-menu"
                  role="menu"
                  aria-label="Download options menu"
                  onMouseLeave={() => setShowDownloadMenu(false)}
                >
                  <div className="py-1">
                    <button
                      onClick={downloadCompleteStructure}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center space-x-2"
                      data-testid="download-complete-structure"
                      role="menuitem"
                      aria-label="Download complete JSON structure"
                    >
                      <Archive className="w-4 h-4" />
                      <span>Complete JSON Structure</span>
                    </button>

                    <button
                      onClick={downloadCurrentView}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center space-x-2"
                      disabled={!currentItems.length}
                      data-testid="download-current-view"
                      role="menuitem"
                      aria-label="Download current view as JSON"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Current View as JSON</span>
                    </button>

                    {searchResults.length > 0 && (
                      <button
                        onClick={downloadSearchResults}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center space-x-2"
                        data-testid="download-search-results"
                        role="menuitem"
                        aria-label={`Download search results (${searchResults.length} items)`}
                      >
                        <FileText className="w-4 h-4" />
                        <span>Search Results ({searchResults.length})</span>
                      </button>
                    )}

                    <button
                      onClick={downloadFileList}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center space-x-2"
                      data-testid="download-file-list"
                      role="menuitem"
                      aria-label="Download file list as CSV"
                    >
                      <Table className="w-4 h-4" />
                      <span>File List as CSV</span>
                    </button>

                    <div className="border-t border-gray-200 my-1"></div>

                    <button
                      onClick={() => {
                        setShowHTMLExportModal(true)
                        setShowDownloadMenu(false)
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700 flex items-center space-x-2"
                      data-testid="export-html"
                      role="menuitem"
                      aria-label="Export as HTML for WordPress"
                    >
                      <Globe className="w-4 h-4" />
                      <span>Export as HTML</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Clear Button */}
              <button
                onClick={() => setShowConfirmClear(true)}
                className="flex items-center space-x-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
                data-testid="clear-button"
                aria-label="Clear all data"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="hidden sm:inline">Clear</span>
              </button>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="mt-3 flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-4">
              <span>{currentItems.length} items in current view</span>
              {searchQuery && (
                <span className="text-blue-600">
                  Search: "{searchQuery}" ({searchResults.length} results)
                </span>
              )}
            </div>
            <div className="text-xs text-gray-500 truncate max-w-xs">Source: {dataSource}</div>
          </div>
        </div>
      </div>

      {/* Confirm Clear Dialog */}
      <ConfirmDialog
        isOpen={showConfirmClear}
        title="Clear All Data"
        message="Are you sure you want to clear all loaded data? This will reset the application to its initial state and cannot be undone."
        onConfirm={handleDownloadComplete}
        onCancel={() => setShowConfirmClear(false)}
      />

      {/* HTML Export Modal */}
      <HTMLExportModal
        isOpen={showHTMLExportModal}
        onClose={() => setShowHTMLExportModal(false)}
        data={data}
        dataSource={dataSource}
        onSuccess={(message) => showNotification(message, "success")}
        onError={(message) => showNotification(message, "error")}
      />

      {/* Notification */}
      {notification && (
        <Notification message={notification.message} type={notification.type} onClose={() => setNotification(null)} />
      )}
    </>
  )
}
